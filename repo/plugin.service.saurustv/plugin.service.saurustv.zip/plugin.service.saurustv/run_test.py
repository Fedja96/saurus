# Manueller Teststart über „Ausführen“, ohne Kodi-Neustart
import service
service.main()
